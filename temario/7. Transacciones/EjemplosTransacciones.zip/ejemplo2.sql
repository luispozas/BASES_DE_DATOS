-- ----------------------------------------------------
-- Ejemplo 2.
-- ----------------------------------------------------

-- ¿Cuál es el estado de la BD después de ejecutar las siguientes
-- sentencias?

SET TRANSACTION NAME 'sal_update';
UPDATE empl SET salario = 7000 WHERE NIF= '40D';

SAVEPOINT after_salario;
UPDATE empl SET salario = salario + 100 WHERE NIF= '40D';

ROLLBACK TO SAVEPOINT after_salario;
UPDATE empl SET salario = salario + 250 WHERE NIF= '40D';
COMMIT;

