-- ----------------------------------------------------
-- Ejemplo 1.
-- ----------------------------------------------------

-- ¿Cuál es el estado de la BD después de ejecutar las siguientes
-- sentencias?

DROP TABLE empl; 
CREATE TABLE empl (
  NIF VARCHAR2(9) PRIMARY KEY,
  NOMBRE VARCHAR2(20),
  SALARIO NUMBER(8,2)
);

INSERT INTO empl VALUES ('10A','Jorge Perez',3000.11);
ROLLBACK;
INSERT INTO empl VALUES ('30C','Javier Sala',2000.22);
INSERT INTO empl VALUES ('30C','Soledad Lopez',2000.33);
INSERT INTO empl VALUES ('40D','Sonia Moldes',1800.44);
INSERT INTO empl VALUES ('50E','Antonio Lopez',1800.44);
COMMIT;
INSERT INTO empl VALUES ('70C','Soledad Martin',2000.33);

SELECT * FROM empl; -- (verlo en cada una de las sentencias anteriores)

-- ¿Cuál es el estado de la BD visible desde otras sesiones?}  
-- (desde otra conexion)

SELECT * FROM empl;

